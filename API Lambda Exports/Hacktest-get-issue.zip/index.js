console.log('Writing Data');
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = function(event, context, callback) {
    var p = {
        TableName: "Hacktest",
        Key:{
            "issueID": event.params.querystring.id
        }
    };
    docClient.get(p,function(err, data) {
        if (err) {
            console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));
        } else {
            //var item = JSON.stringify(data, null, 2);
            var item = data.Item;
            callback(null,item);
        }
    });
}
exports.handler = (event, context, callback) => {
    // TODO implement
    callback(null, '{"Events": {"1": {"EventName": "String Title","Topic":"String Example","Geo": {"Lat": 12.34567,"Long": 123.456789},"Tags": ["Tag 1", "Tag 2", "Tag 3"],"Summary": "String text","Author": "String name","Story": "String Theory Explained","Votes": 123}}}');
};
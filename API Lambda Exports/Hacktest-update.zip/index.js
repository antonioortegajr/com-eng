console.log('Writing Data');
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = function(event, context, callback) {
    var p = {
        TableName: "Hacktest",
        Key:{
            "issueID": event.body.issueID
        }
    };
    docClient.get(p,function(err, data) {
        if (err) {
            console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));
        } else {
            //var item = JSON.stringify(data, null, 2);
            var item = data.Item;
            console.log(item);
            var newUser = event.body.voteUsers;
            var Votes = item.Votes;
            console.log(Votes);
            Votes = Votes + 1;
            console.log(Votes);
            var users = JSON.parse(item.voteUsers);
            users.push(newUser);
            users = JSON.stringify(users);
            var params = {
                TableName: "Hacktest",
                Key:{
                    "issueID": event.body.issueID
                },
                UpdateExpression: "set Votes=:Votes, voteUsers=:users",
                ExpressionAttributeValues:{
                    ":Votes": Votes,
                    ":users": users
                },
                ReturnValues:"UPDATED_NEW"
            }
            docClient.update(params, function(err, data) {
    	    	if(err) {
    	    		callback(err, null);
        		} else {
        			const response = {
    	    		  statusCode: 200,
	        		  headers: {
	        			'Access-Control-Allow-Origin' : '*',
                        'Access-Control-Allow-Headers': '*',
                        'Access-Control-Allow-Credentials' : true,
                        'Content-Type': 'application/json'
	    	    	  },
	    		      body: JSON.stringify({ "message": "Issue Submitted Successfully" })
	    	    	};
	    	    	callback(null, response);
	        	}
        	});
        }
    });
};
console.log('Writing Data');
const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'us-west-2'});

exports.handler = function(event, context, callback) {
	var params = {
		Item: {
			issueID: event.body.issueID,
			issueName: event.body.issueName,
			Topic: event.body.Topic,
			Lat: event.body.Lat,
			Long: event.body.Long,
			Tags: event.body.Tags,
			Summary: event.body.Summary,
			Author: event.body.Author,
			Story: event.body.Story,
			Votes: event.body.Votes,
			Creator: event.body.Creator,
			voteUsers: event.body.voteUsers,
			createdDate: event.body.createdDate
		},
		TableName: 'Hacktest'
	};
	docClient.put(params, function(err, data) {
		if(err) {
			callback(err, null);
		} else {
			const response = {
			  statusCode: 200,
			  headers: {
				'Access-Control-Allow-Origin' : '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Credentials' : true,
                'Content-Type': 'application/json'
			  },
			  body: JSON.stringify({ "message": "Issue Submitted Successfully" })
			};
			callback(null, response);
		}
	});
}